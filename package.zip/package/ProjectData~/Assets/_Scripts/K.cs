using UnityEngine;

public class K : MonoBehaviour{

    public static class Tag{
        public static string Player = "Player";
    }

    public static class Prefs{
        public static string Level = "Level";
    }
    
}
